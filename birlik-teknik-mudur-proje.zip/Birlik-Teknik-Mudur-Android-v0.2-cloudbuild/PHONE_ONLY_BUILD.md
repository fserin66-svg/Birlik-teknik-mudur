# Telefonda APK üretme (GitHub Actions)

Bu proje GitHub'a yüklendiğinde `.github/workflows/build-apk.yml` otomatik olarak Android APK derlemesi başlatır.

Derleme sonucu GitHub > Actions > en son başarılı çalışma > Artifacts bölümünde `Birlik-Teknik-Mudur-APK` adıyla çıkar. Zip açıldığında `Birlik-Teknik-Mudur.apk` bulunur.

Not: İlk kurulumda Android, APK dosyasını açtığınız uygulama için “Bilinmeyen uygulamaları yükle” izni isteyebilir.
