# Birlik Teknik Müdür — Android v0.1

Bu proje mevcut offline Birlik Teknik Müdür uygulamasını Android WebView içinde gerçek uygulama olarak çalıştırır.

## Özellikler
- Ana ekranda gerçek uygulama ikonu
- Tarayıcı olmadan tam ekran kullanım
- Servis / stok / para kayıtlarının cihazda kalıcı saklanması (WebView localStorage)
- Cihaz fotoğrafı seçimi
- JSON yedek dosyasını Android dosya seçicisiyle kaydetme
- İnternet izni istemez; v0.1 tamamen offline'dır

## Derleme
1. Android Studio ile bu klasörü açın.
2. SDK 35 eksikse Android Studio'nun kurmasına izin verin.
3. Build > Build APK(s).
4. Debug APK: `app/build/outputs/apk/debug/app-debug.apk`

## Not
ChatGPT ile canlı veri bağlantısı v0.1'de yoktur. Bunun için sonraki aşamada HTTPS backend + kimlik doğrulama + MCP/API katmanı eklenmelidir.
